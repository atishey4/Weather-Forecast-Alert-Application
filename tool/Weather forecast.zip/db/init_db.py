"""
db/init_db.py
=============
Creates the SQLite database from schema.sql and seeds it with
three Indian city locations.

Usage:
    python db/init_db.py                  # from project root
    python -m db.init_db                  # as a module
"""

from __future__ import annotations

import logging
import sqlite3
from pathlib import Path

# ── Paths ──────────────────────────────────────────────────────────────────
ROOT      = Path(__file__).resolve().parent.parent   # project root
DB_PATH   = ROOT / "db" / "weather.db"
SCHEMA    = ROOT / "db" / "schema.sql"

# ── Logging ────────────────────────────────────────────────────────────────
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s - %(message)s",
)
logger = logging.getLogger(__name__)

# ── Seed data ──────────────────────────────────────────────────────────────
SEED_LOCATIONS: list[dict] = [
    {"name": "Delhi",     "lat": 28.61, "lon": 77.21, "tz": "Asia/Kolkata"},
    {"name": "Mumbai",    "lat": 19.07, "lon": 72.87, "tz": "Asia/Kolkata"},
    {"name": "Bengaluru", "lat": 12.97, "lon": 77.59, "tz": "Asia/Kolkata"},
]


# ── Helpers ────────────────────────────────────────────────────────────────

def get_connection() -> sqlite3.Connection:
    """Return a WAL-enabled connection with FK enforcement."""
    conn = sqlite3.connect(DB_PATH)
    conn.execute("PRAGMA journal_mode = WAL;")
    conn.execute("PRAGMA foreign_keys = ON;")
    conn.row_factory = sqlite3.Row
    return conn


def apply_schema(conn: sqlite3.Connection) -> None:
    """Execute schema.sql against the open connection."""
    sql = SCHEMA.read_text(encoding="utf-8")
    conn.executescript(sql)
    logger.info("Schema applied from %s", SCHEMA)


def seed_locations(conn: sqlite3.Connection) -> None:
    """Insert seed cities, skipping duplicates (UNIQUE lat+lon)."""
    insert_sql = """
        INSERT INTO locations (name, lat, lon, tz)
        VALUES (:name, :lat, :lon, :tz)
        ON CONFLICT (lat, lon) DO UPDATE SET
            name = excluded.name,
            tz   = excluded.tz;
    """
    for city in SEED_LOCATIONS:
        conn.execute(insert_sql, city)
        logger.info(
            "  ✔ Upserted location: %s (%.4f, %.4f) [%s]",
            city["name"], city["lat"], city["lon"], city["tz"],
        )
    conn.commit()
    logger.info("Seed complete — %d location(s) processed.", len(SEED_LOCATIONS))


def verify(conn: sqlite3.Connection) -> None:
    """Print a quick summary of the seeded rows."""
    rows = conn.execute(
        "SELECT id, name, lat, lon, tz FROM locations ORDER BY id;"
    ).fetchall()
    logger.info("── Locations in DB ────────────────────────────")
    for row in rows:
        logger.info(
            "  [%d] %-12s  lat=%-7.4f  lon=%-7.4f  tz=%s",
            row["id"], row["name"], row["lat"], row["lon"], row["tz"],
        )
    logger.info("───────────────────────────────────────────────")


# ── Entry point ────────────────────────────────────────────────────────────

def init() -> None:
    """Full initialisation: schema → seed → verify."""
    logger.info("DB path : %s", DB_PATH)
    logger.info("Schema  : %s", SCHEMA)

    DB_PATH.parent.mkdir(parents=True, exist_ok=True)

    with get_connection() as conn:
        apply_schema(conn)
        seed_locations(conn)
        verify(conn)

    logger.info("Database initialised successfully.")


if __name__ == "__main__":
    init()
