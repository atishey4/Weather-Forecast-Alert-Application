-- =============================================================
-- Weather Forecast Alert Application — SQLite Schema
-- =============================================================
-- Run via:  python db/init_db.py
-- Or apply directly:  sqlite3 db/weather.db < db/schema.sql
-- =============================================================

PRAGMA journal_mode = WAL;
PRAGMA foreign_keys = ON;

-- -------------------------------------------------------------
-- 1. locations
--    Master list of monitored geographic locations.
-- -------------------------------------------------------------
CREATE TABLE IF NOT EXISTS locations (
    id      INTEGER PRIMARY KEY AUTOINCREMENT,
    name    TEXT    NOT NULL,
    lat     REAL    NOT NULL,
    lon     REAL    NOT NULL,
    tz      TEXT    NOT NULL DEFAULT 'UTC',   -- IANA tz, e.g. "Asia/Kolkata"
    UNIQUE (lat, lon)
);

-- -------------------------------------------------------------
-- 2. weather_raw
--    Stores the full API response payload for auditing /
--    replay without loss of upstream data.
-- -------------------------------------------------------------
CREATE TABLE IF NOT EXISTS weather_raw (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    location_id INTEGER NOT NULL REFERENCES locations(id) ON DELETE CASCADE,
    fetched_at  TEXT    NOT NULL,           -- ISO-8601 UTC timestamp
    scope       TEXT    NOT NULL,           -- e.g. "current" | "hourly" | "daily"
    provider    TEXT    NOT NULL,           -- e.g. "openweathermap" | "open-meteo"
    payload     TEXT    NOT NULL            -- JSON blob from the API
);

CREATE INDEX IF NOT EXISTS idx_raw_location_fetched
    ON weather_raw (location_id, fetched_at DESC);

-- -------------------------------------------------------------
-- 3. weather_hourly
--    Processed hourly forecast data, one row per location + hour.
-- -------------------------------------------------------------
CREATE TABLE IF NOT EXISTS weather_hourly (
    location_id     INTEGER NOT NULL REFERENCES locations(id) ON DELETE CASCADE,
    ts              TEXT    NOT NULL,   -- ISO-8601 UTC hour timestamp
    temp_c          REAL,
    feels_c         REAL,
    humidity        REAL,               -- %
    wind_ms         REAL,               -- m/s sustained
    wind_gust_ms    REAL,               -- m/s gust
    precip_mm       REAL,               -- precipitation amount
    precip_prob     REAL,               -- probability 0–1
    cloud_pct       REAL,               -- cloud cover %
    uv              REAL,               -- UV index
    pressure_hpa    REAL,               -- hPa
    visibility_km   REAL,
    weather_code    INTEGER,            -- WMO / OWM condition code
    PRIMARY KEY (location_id, ts)
);

CREATE INDEX IF NOT EXISTS idx_hourly_ts
    ON weather_hourly (ts DESC);

-- -------------------------------------------------------------
-- 4. weather_daily
--    Processed daily summary data, one row per location + date.
-- -------------------------------------------------------------
CREATE TABLE IF NOT EXISTS weather_daily (
    location_id INTEGER NOT NULL REFERENCES locations(id) ON DELETE CASCADE,
    date        TEXT    NOT NULL,   -- ISO-8601 date "YYYY-MM-DD"
    tmax_c      REAL,
    tmin_c      REAL,
    rain_mm     REAL,
    rain_prob   REAL,               -- probability 0–1
    wind_max_ms REAL,               -- m/s
    uv_max      REAL,
    sunrise     TEXT,               -- ISO-8601 local time
    sunset      TEXT,               -- ISO-8601 local time
    PRIMARY KEY (location_id, date)
);

CREATE INDEX IF NOT EXISTS idx_daily_date
    ON weather_daily (date DESC);

-- -------------------------------------------------------------
-- 5. alert_log
--    Immutable audit trail of every alert dispatched.
-- -------------------------------------------------------------
CREATE TABLE IF NOT EXISTS alert_log (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    location_id INTEGER NOT NULL REFERENCES locations(id) ON DELETE CASCADE,
    code        TEXT    NOT NULL,   -- e.g. "HEAVY_RAIN" | "HEAT_WAVE" | "HIGH_UV"
    sent_at     TEXT    NOT NULL    -- ISO-8601 UTC timestamp
);

CREATE INDEX IF NOT EXISTS idx_alert_location_sent
    ON alert_log (location_id, sent_at DESC);
