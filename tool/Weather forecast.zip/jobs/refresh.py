"""
jobs/refresh.py
===============
Fetches fresh forecast data from Open-Meteo for every location in the DB
and persists both the raw payload and the parsed series.

Usage
-----
    python jobs/refresh.py               # run once from project root
    python -m jobs.refresh               # as a module
    from jobs.refresh import refresh_all # imported by scheduler
"""

from __future__ import annotations

import logging
import sys
import time
from pathlib import Path

# ── Path bootstrap ──────────────────────────────────────────────────────────
ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from db.init_db import get_connection          # noqa: E402
from src.ingest import (                       # noqa: E402
    fetch_open_meteo,
    persist_raw,
    upsert_series,
)

logger = logging.getLogger(__name__)

# Polite delay between location requests to avoid hammering the API
_REQUEST_DELAY_S = 1.5


# ── Main job function ───────────────────────────────────────────────────────

def refresh_all(db: str = "db/weather.db") -> dict[str, int]:
    """
    Fetch and persist forecasts for every location stored in the database.

    Parameters
    ----------
    db : path to the SQLite database file, relative to the project root
         or an absolute path.

    Returns
    -------
    dict with keys:
        total     – number of locations processed
        success   – number of successful fetches
        failed    – number of failed fetches
    """
    db_path = ROOT / db if not Path(db).is_absolute() else Path(db)
    logger.info("── refresh_all started  db=%s ──────────────────────────", db_path)

    conn = get_connection()
    locations = conn.execute(
        "SELECT id, name, lat, lon, tz FROM locations ORDER BY id;"
    ).fetchall()
    conn.close()

    if not locations:
        logger.warning("No locations found in DB — nothing to refresh.")
        return {"total": 0, "success": 0, "failed": 0}

    success = 0
    failed  = 0

    for loc in locations:
        loc_id = loc["id"]
        name   = loc["name"]
        lat    = loc["lat"]
        lon    = loc["lon"]
        tz     = loc["tz"]

        logger.info("  → Refreshing  [%d] %s  (%.4f, %.4f)", loc_id, name, lat, lon)

        try:
            payload = fetch_open_meteo(lat=lat, lon=lon, tz=tz)

            conn = get_connection()
            persist_raw(conn, loc_id, payload, scope="full")
            upsert_series(conn, loc_id, payload)
            conn.close()

            success += 1
            logger.info("    ✔ Done: [%d] %s", loc_id, name)

        except Exception as exc:
            failed += 1
            logger.error("    ✘ Failed: [%d] %s — %s", loc_id, name, exc, exc_info=True)

        # Small pause between requests regardless of success/failure
        if loc != locations[-1]:
            time.sleep(_REQUEST_DELAY_S)

    summary = {"total": len(locations), "success": success, "failed": failed}
    logger.info(
        "── refresh_all complete  total=%d  success=%d  failed=%d ──",
        summary["total"], summary["success"], summary["failed"],
    )
    return summary


# ── Standalone entry point ──────────────────────────────────────────────────

if __name__ == "__main__":
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(name)s - %(message)s",
    )
    result = refresh_all()
    sys.exit(0 if result["failed"] == 0 else 1)
