"""
jobs/scheduler.py
=================
APScheduler-based background scheduler.

Schedule
--------
  refresh_all()          every 2 hours   (runs immediately on start)
  evaluate_and_notify()  every 30 minutes (runs immediately on start)

Usage
-----
    python jobs/scheduler.py      # runs in the foreground; Ctrl-C to stop
    python -m jobs.scheduler
"""

from __future__ import annotations

import logging
import signal
import sys
from datetime import datetime
from pathlib import Path

from apscheduler.events import EVENT_JOB_ERROR, EVENT_JOB_EXECUTED, JobExecutionEvent
from apscheduler.schedulers.blocking import BlockingScheduler
from apscheduler.triggers.interval import IntervalTrigger

# ── Path bootstrap ──────────────────────────────────────────────────────────
ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from jobs.refresh import refresh_all          # noqa: E402
from notify.alert import evaluate_and_notify  # noqa: E402

# ── Logging ─────────────────────────────────────────────────────────────────
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s - %(message)s",
)
logger = logging.getLogger(__name__)

# ── Scheduler timezone ──────────────────────────────────────────────────────
_TZ = "Asia/Kolkata"

# ── Job identifiers ─────────────────────────────────────────────────────────
JOB_REFRESH  = "refresh_all"
JOB_EVALUATE = "evaluate_and_notify"

# ── Job configuration ────────────────────────────────────────────────────────
_JOB_CONFIGS = [
    {
        "id":       JOB_REFRESH,
        "func":     refresh_all,
        "trigger":  IntervalTrigger(hours=2, timezone=_TZ),
        "name":     "Open-Meteo full refresh (all locations)",
    },
    {
        "id":       JOB_EVALUATE,
        "func":     evaluate_and_notify,
        "trigger":  IntervalTrigger(minutes=30, timezone=_TZ),
        "name":     "Alert rule evaluation + notification",
    },
]


# ── APScheduler event listener ──────────────────────────────────────────────

def _on_job_event(event: JobExecutionEvent) -> None:
    """Log job success / failure after each execution."""
    if event.exception:
        logger.error(
            "Job [%s] FAILED with exception: %s",
            event.job_id, event.exception, exc_info=event.traceback,
        )
    else:
        logger.info(
            "Job [%s] completed successfully.  retval=%s",
            event.job_id, event.retval,
        )


# ── Scheduler builder ───────────────────────────────────────────────────────

def build_scheduler() -> BlockingScheduler:
    """Construct and configure the scheduler (does not start it)."""
    scheduler = BlockingScheduler(timezone=_TZ)
    scheduler.add_listener(_on_job_event, EVENT_JOB_EXECUTED | EVENT_JOB_ERROR)

    now = datetime.now()

    for cfg in _JOB_CONFIGS:
        scheduler.add_job(
            func         = cfg["func"],
            trigger      = cfg["trigger"],
            id           = cfg["id"],
            name         = cfg["name"],
            # next_run_time=now causes APScheduler to run the job immediately
            # on scheduler.start() before waiting for the first interval.
            next_run_time = now,
            max_instances = 1,          # prevent overlap if a run takes too long
            coalesce      = True,       # skip missed runs instead of piling up
        )
        logger.info(
            "  ✔ Registered job [%s]: %s", cfg["id"], cfg["name"]
        )

    return scheduler


# ── Graceful shutdown ────────────────────────────────────────────────────────

def _shutdown(scheduler: BlockingScheduler, signum: int, frame) -> None:  # type: ignore[type-arg]
    logger.info("Signal %d received — shutting down scheduler gracefully …", signum)
    scheduler.shutdown(wait=False)
    logger.info("Scheduler stopped.")
    sys.exit(0)


# ── Entry point ──────────────────────────────────────────────────────────────

def main() -> None:
    logger.info("════════════════════════════════════════════════")
    logger.info("  Weather Forecast Alert — Job Scheduler")
    logger.info("  Timezone : %s", _TZ)
    logger.info("  Jobs     :")
    logger.info("    %-22s every 2 hours",   JOB_REFRESH)
    logger.info("    %-22s every 30 minutes", JOB_EVALUATE)
    logger.info("  (Both jobs run immediately on startup)")
    logger.info("════════════════════════════════════════════════")

    scheduler = build_scheduler()

    # Register SIGTERM / SIGINT for clean container/process shutdown
    signal.signal(signal.SIGINT,  lambda s, f: _shutdown(scheduler, s, f))
    signal.signal(signal.SIGTERM, lambda s, f: _shutdown(scheduler, s, f))

    try:
        logger.info("Scheduler starting — press Ctrl-C to stop.")
        scheduler.start()
    except (KeyboardInterrupt, SystemExit):
        logger.info("Scheduler exiting.")


if __name__ == "__main__":
    main()
