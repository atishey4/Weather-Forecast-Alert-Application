"""
main.py
=======
Weather Forecast Alert Application — CLI entry point.

Modes
-----
  --mode api       Refresh all locations then start FastAPI on port 8000.
  --mode simulate  Run offline simulation (sample JSON), generate charts,
                   print per-city terminal summary.

Usage
-----
  python main.py --mode simulate
  python main.py --mode api
  python main.py --mode api --port 8080
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

# ── Path bootstrap ──────────────────────────────────────────────────────────
ROOT = Path(__file__).resolve().parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from dotenv import load_dotenv
load_dotenv(ROOT / ".env")

import logging
logging.basicConfig(
    level=logging.WARNING,                     # keep noise low for CLI output
    format="%(asctime)s [%(levelname)s] %(name)s — %(message)s",
)

# ══════════════════════════════════════════════════════════════════════════════
# Banner
# ══════════════════════════════════════════════════════════════════════════════

_WARN_BANNER = """
╔══════════════════════════════════════════════════════════════╗
║  ⚠   EDUCATIONAL PROJECT — NOT A PROFESSIONAL SERVICE   ⚠   ║
║  This project is for educational purposes only.              ║
║  Do NOT rely on it for safety-critical weather decisions.    ║
╚══════════════════════════════════════════════════════════════╝
"""

_APP_BANNER = """
╔══════════════════════════════════════════════════════════════╗
║       🌤   Weather Forecast & Alert Application  🌤          ║
║            Powered by Open-Meteo (free, no key)              ║
╚══════════════════════════════════════════════════════════════╝
"""

SEV_ICON = {"critical": "🔴", "warn": "⚠️ ", "info": "ℹ️ "}


# ══════════════════════════════════════════════════════════════════════════════
# Helpers
# ══════════════════════════════════════════════════════════════════════════════

def _sma_signal(conn, loc_id: int) -> str:
    """
    Compute temperature trend signal using short (6-h) vs long (24-h) SMA.
    Returns "RISING ↑", "FALLING ↓", or "STABLE →".
    """
    rows = conn.execute(
        """
        SELECT temp_c FROM weather_hourly
        WHERE location_id = ? AND temp_c IS NOT NULL
        ORDER BY ts DESC LIMIT 24;
        """,
        (loc_id,),
    ).fetchall()

    temps = [r["temp_c"] for r in rows if r["temp_c"] is not None]
    if len(temps) < 6:
        return "N/A"

    short_sma = sum(temps[:6])  / 6
    long_sma  = sum(temps)      / len(temps)

    diff = short_sma - long_sma
    if diff > 0.5:
        return "RISING  ↑"
    elif diff < -0.5:
        return "FALLING ↓"
    return "STABLE  →"


def _latest_conditions(conn, loc_id: int) -> dict:
    """Return the most-recent hourly row as a dict (or empty dict)."""
    row = conn.execute(
        """
        SELECT ts, temp_c, humidity
        FROM weather_hourly
        WHERE location_id = ? AND temp_c IS NOT NULL
        ORDER BY ts DESC LIMIT 1;
        """,
        (loc_id,),
    ).fetchone()
    return dict(row) if row else {}


def _fired_codes(loc_id: int) -> list[str]:
    """Run evaluate() against ALL rows for loc_id and return alert codes."""
    from db.init_db import get_connection
    from src.rules import evaluate

    conn = get_connection()
    h_rows = conn.execute(
        "SELECT * FROM weather_hourly WHERE location_id=? ORDER BY ts;",
        (loc_id,),
    ).fetchall()
    d_rows = conn.execute(
        "SELECT * FROM weather_daily WHERE location_id=? ORDER BY date;",
        (loc_id,),
    ).fetchall()
    conn.close()

    fired = evaluate(h_rows, d_rows)
    return [a["code"] for a in fired]


def _print_city_summary(loc: dict, conn) -> Path | None:
    """Print one-line summary row for a city and return the report path."""
    from src.report import generate_report

    loc_id = loc["id"]
    name   = loc["name"]

    cond   = _latest_conditions(conn, loc_id)
    signal = _sma_signal(conn, loc_id)
    codes  = _fired_codes(loc_id)
    codes_str = ", ".join(codes) if codes else "none"

    temp_str = f"{cond.get('temp_c', '—'):.1f}°C" if cond.get("temp_c") is not None else "—"
    hum_str  = f"{cond.get('humidity', '—'):.0f}%"  if cond.get("humidity") is not None else "—"

    # Generate CSV report
    try:
        report_path = generate_report(loc_id)
    except Exception:
        report_path = None

    print(f"  {'City':<12} {name}")
    print(f"  {'Temp':<12} {temp_str}")
    print(f"  {'Humidity':<12} {hum_str}")
    print(f"  {'SMA Signal':<12} {signal}")
    print(f"  {'Alerts':<12} {codes_str}")
    print(f"  {'Report':<12} {report_path or 'N/A'}")
    return report_path


def _section(title: str) -> None:
    width = 62
    print(f"\n{'─' * width}")
    print(f"  {title}")
    print('─' * width)


# ══════════════════════════════════════════════════════════════════════════════
# Mode: simulate
# ══════════════════════════════════════════════════════════════════════════════

def mode_simulate() -> None:
    from db.init_db import get_connection, init
    from src.simulate import run_simulation
    from src.plots import temp_trend, rain_forecast, humidity_wind, alert_summary
    from src.rules import evaluate
    import pandas as pd

    _section("Initialising database")
    init()

    _section("Running offline simulation")
    run_simulation()                          # upserts Delhi data, prints step log

    # ── Per-city terminal summary ──────────────────────────────────────────
    _section("Terminal Summary — All Cities")
    conn = get_connection()
    locs = conn.execute(
        "SELECT id, name, lat, lon, tz FROM locations ORDER BY id;"
    ).fetchall()

    for loc in locs:
        loc_d  = dict(loc)
        loc_id = loc_d["id"]
        name   = loc_d["name"]

        print(f"\n  ┌─ {name.upper()} {'─' * (50 - len(name))}")
        _print_city_summary(loc_d, conn)
        print(f"  └{'─' * 54}")

        # Generate charts for every city that has data
        h_rows = conn.execute(
            "SELECT * FROM weather_hourly WHERE location_id=? ORDER BY ts;",
            (loc_id,),
        ).fetchall()
        d_rows = conn.execute(
            "SELECT * FROM weather_daily WHERE location_id=? ORDER BY date;",
            (loc_id,),
        ).fetchall()

        if h_rows:
            h_df = pd.DataFrame([dict(r) for r in h_rows])
            temp_trend(h_df.head(24), name)
            humidity_wind(h_df.head(24), name)

        if d_rows:
            d_df = pd.DataFrame([dict(r) for r in d_rows])
            rain_forecast(d_df, name)

        fired = evaluate(h_rows, d_rows)
        alert_summary(fired, name)

    conn.close()

    _section("Outputs")
    print(f"  Charts  → {ROOT / 'outputs'}/")
    print(f"  Reports → {ROOT / 'reports'}/")


# ══════════════════════════════════════════════════════════════════════════════
# Mode: api
# ══════════════════════════════════════════════════════════════════════════════

def mode_api(port: int) -> None:
    import uvicorn
    from db.init_db import init, get_connection
    from jobs.refresh import refresh_all
    from src.rules import evaluate

    _section("Initialising database")
    init()

    _section("Refreshing all locations from Open-Meteo")
    result = refresh_all()
    print(
        f"  Fetched  total={result['total']}  "
        f"success={result['success']}  failed={result['failed']}"
    )

    # ── Terminal summary after live fetch ──────────────────────────────────
    _section("Terminal Summary — All Cities")
    conn = get_connection()
    locs = conn.execute(
        "SELECT id, name, lat, lon, tz FROM locations ORDER BY id;"
    ).fetchall()

    for loc in locs:
        loc_d = dict(loc)
        name  = loc_d["name"]
        print(f"\n  ┌─ {name.upper()} {'─' * (50 - len(name))}")
        _print_city_summary(loc_d, conn)
        print(f"  └{'─' * 54}")

    conn.close()

    _section(f"Starting FastAPI server on port {port}")
    print(f"  API docs  → http://127.0.0.1:{port}/docs")
    print(f"  Dashboard → streamlit run src/app_streamlit.py\n")

    uvicorn.run(
        "api.app:app",
        host="0.0.0.0",
        port=port,
        log_level="info",
        reload=False,
    )


# ══════════════════════════════════════════════════════════════════════════════
# Entry point
# ══════════════════════════════════════════════════════════════════════════════

def _parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        prog="main.py",
        description="Weather Forecast Alert Application",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=(
            "Examples:\n"
            "  python main.py --mode simulate\n"
            "  python main.py --mode api\n"
            "  python main.py --mode api --port 8080\n"
        ),
    )
    parser.add_argument(
        "--mode",
        choices=["api", "simulate"],
        required=True,
        help="'api' — refresh + start server | 'simulate' — offline demo",
    )
    parser.add_argument(
        "--port",
        type=int,
        default=8000,
        help="Port for the FastAPI server (api mode only, default 8000)",
    )
    return parser.parse_args()


def main() -> None:
    print(_APP_BANNER)
    print(_WARN_BANNER)

    args = _parse_args()

    if args.mode == "simulate":
        mode_simulate()
    elif args.mode == "api":
        mode_api(args.port)


if __name__ == "__main__":
    main()
