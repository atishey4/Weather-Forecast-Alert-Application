"""
notify/alert.py
===============
Alert evaluation, deduplication, and dispatch layer.

Public API
----------
telegram_send(bot_token, chat_id, text)          → bool
smtp_send(to_email, subject, body)               → bool
dispatch_if_new(location_id, alerts, conn)       → list[dict]   (alerts actually sent)
evaluate_and_notify(db="db/weather.db")          → dict         (called by scheduler)
"""

from __future__ import annotations

import logging
import os
import smtplib
import sys
from datetime import datetime, timedelta, timezone
from email.mime.text import MIMEText
from pathlib import Path

import requests
from dotenv import load_dotenv

# ── Path bootstrap ──────────────────────────────────────────────────────────
ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

# Load .env as early as possible so every import below can read env vars
load_dotenv(ROOT / ".env")

from db.init_db import get_connection  # noqa: E402
from src.rules import evaluate         # noqa: E402

logger = logging.getLogger(__name__)

# Debounce window — same location+code will not re-fire within this period
_DEBOUNCE_HOURS = 12

# Severity → emoji prefix for human-readable messages
_SEVERITY_ICON = {
    "info":     "ℹ️",
    "warn":     "⚠️",
    "critical": "🔴",
}


# ══════════════════════════════════════════════════════════════════════════
# 1. Transport functions
# ══════════════════════════════════════════════════════════════════════════

def telegram_send(bot_token: str, chat_id: str, text: str) -> bool:
    """
    Send a plain-text or HTML message via the Telegram Bot API.

    Parameters
    ----------
    bot_token : Telegram bot token (from BotFather)
    chat_id   : Target chat / channel / group ID
    text      : Message body (HTML tags are supported)

    Returns
    -------
    True if the message was accepted by Telegram, False otherwise.
    """
    url = f"https://api.telegram.org/bot{bot_token}/sendMessage"
    params = {
        "chat_id":    chat_id,
        "text":       text,
        "parse_mode": "HTML",
    }
    try:
        resp = requests.get(url, params=params, timeout=10)
        resp.raise_for_status()
        data = resp.json()
        if data.get("ok"):
            logger.info("  ✔ Telegram message sent to chat_id=%s", chat_id)
            return True
        logger.error("  ✘ Telegram API error: %s", data.get("description", data))
        return False
    except requests.RequestException as exc:
        logger.error("  ✘ Telegram request failed: %s", exc)
        return False


def smtp_send(to_email: str, subject: str, body: str) -> bool:
    """
    Send an email via SMTP using credentials from the environment.

    Required .env variables
    -----------------------
    SMTP_HOST   e.g. smtp.gmail.com
    SMTP_PORT   e.g. 587
    SMTP_USER   sender login / address
    SMTP_PASS   app password or SMTP password
    SMTP_FROM   From: address (defaults to SMTP_USER if unset)

    Parameters
    ----------
    to_email : recipient address
    subject  : email subject line
    body     : plain-text message body

    Returns
    -------
    True on success, False on any error.
    """
    host      = os.environ.get("SMTP_HOST", "")
    port      = int(os.environ.get("SMTP_PORT", 587))
    user      = os.environ.get("SMTP_USER", "")
    password  = os.environ.get("SMTP_PASS", "")
    from_addr = os.environ.get("SMTP_FROM", user)

    if not all([host, user, password]):
        logger.warning(
            "smtp_send: SMTP_HOST / SMTP_USER / SMTP_PASS not configured — skipping."
        )
        return False

    msg = MIMEText(body, "plain", "utf-8")
    msg["Subject"] = subject
    msg["From"]    = from_addr
    msg["To"]      = to_email

    try:
        with smtplib.SMTP(host, port, timeout=15) as server:
            server.ehlo()
            server.starttls()
            server.login(user, password)
            server.sendmail(from_addr, [to_email], msg.as_string())
        logger.info("  ✔ Email sent to %s — "%s"", to_email, subject)
        return True
    except smtplib.SMTPException as exc:
        logger.error("  ✘ SMTP error: %s", exc)
        return False
    except OSError as exc:
        logger.error("  ✘ Network error sending email: %s", exc)
        return False


# ══════════════════════════════════════════════════════════════════════════
# 2. Deduplication helper
# ══════════════════════════════════════════════════════════════════════════

def _already_fired(conn, location_id: int, code: str, window_hours: int) -> bool:
    """
    Return True if an alert with this (location_id, code) was already
    persisted in alert_log within the last `window_hours` hours.
    """
    cutoff = (
        datetime.now(timezone.utc) - timedelta(hours=window_hours)
    ).strftime("%Y-%m-%dT%H:%M:%SZ")

    row = conn.execute(
        """
        SELECT 1 FROM alert_log
        WHERE location_id = ?
          AND code = ?
          AND sent_at >= ?
        LIMIT 1;
        """,
        (location_id, code, cutoff),
    ).fetchone()
    return row is not None


def _log_to_db(conn, location_id: int, code: str) -> None:
    """Append a sent-alert record to alert_log."""
    sent_at = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    conn.execute(
        "INSERT INTO alert_log (location_id, code, sent_at) VALUES (?, ?, ?);",
        (location_id, code, sent_at),
    )
    conn.commit()


# ══════════════════════════════════════════════════════════════════════════
# 3. dispatch_if_new
# ══════════════════════════════════════════════════════════════════════════

def dispatch_if_new(
    location_id: int,
    location_name: str,
    alerts: list[dict],
    conn,
) -> list[dict]:
    """
    Dispatch alerts that have not fired for this location within the last
    12 hours (debounce), then record them in alert_log.

    Notification channels
    ---------------------
    * Telegram — if TELEGRAM_BOT_TOKEN and TELEGRAM_CHAT_ID are set in env
    * SMTP email — if ALERT_TO_EMAIL and SMTP_* vars are set in env

    Parameters
    ----------
    location_id   : locations.id
    location_name : human-readable city name for message formatting
    alerts        : list of dicts from src.rules.evaluate()
    conn          : open sqlite3.Connection

    Returns
    -------
    List of alert dicts that were actually dispatched (new ones only).
    """
    bot_token  = os.environ.get("TELEGRAM_BOT_TOKEN", "")
    chat_id    = os.environ.get("TELEGRAM_CHAT_ID", "")
    to_email   = os.environ.get("ALERT_TO_EMAIL", "")

    dispatched: list[dict] = []

    for alert in alerts:
        code     = alert["code"]
        label    = alert["label"]
        severity = alert["severity"]

        if _already_fired(conn, location_id, code, _DEBOUNCE_HOURS):
            logger.info(
                "    ↩ [%s] %s — suppressed (already fired within %dh)",
                code, location_name, _DEBOUNCE_HOURS,
            )
            continue

        # ── Build message ────────────────────────────────────────────────
        icon = _SEVERITY_ICON.get(severity, "•")
        tg_text = (
            f"{icon} <b>Weather Alert — {location_name}</b>\n"
            f"<b>[{severity.upper()}]</b> {code}\n"
            f"{label}"
        )
        email_subject = f"[{severity.upper()}] Weather Alert — {location_name}: {code}"
        email_body    = f"{icon} Weather Alert for {location_name}\n\n{label}\n\nSeverity: {severity.upper()}"

        # ── Telegram ─────────────────────────────────────────────────────
        if bot_token and chat_id:
            telegram_send(bot_token, chat_id, tg_text)
        else:
            logger.debug("Telegram not configured — skipping for %s", code)

        # ── SMTP email ───────────────────────────────────────────────────
        if to_email:
            smtp_send(to_email, email_subject, email_body)
        else:
            logger.debug("ALERT_TO_EMAIL not configured — skipping email for %s", code)

        # ── Persist to alert_log ─────────────────────────────────────────
        _log_to_db(conn, location_id, code)
        dispatched.append(alert)
        logger.warning(
            "  %s Dispatched [%s] %s → %s",
            icon, severity.upper(), code, location_name,
        )

    return dispatched


# ══════════════════════════════════════════════════════════════════════════
# 4. Main job (called by scheduler)
# ══════════════════════════════════════════════════════════════════════════

def _fetch_window(conn, location_id: int) -> tuple[list, list]:
    """Return (hourly_rows, daily_rows) for the evaluation window."""
    now_s   = datetime.now().strftime("%Y-%m-%dT%H:%M")
    h48_s   = (datetime.now() + timedelta(hours=48)).strftime("%Y-%m-%dT%H:%M")
    today_s = datetime.now().date().isoformat()
    d3_s    = (datetime.now().date() + timedelta(days=3)).isoformat()

    hourly = conn.execute(
        """
        SELECT * FROM weather_hourly
        WHERE location_id = ? AND ts >= ? AND ts <= ?
        ORDER BY ts;
        """,
        (location_id, now_s, h48_s),
    ).fetchall()

    daily = conn.execute(
        """
        SELECT * FROM weather_daily
        WHERE location_id = ? AND date >= ? AND date <= ?
        ORDER BY date;
        """,
        (location_id, today_s, d3_s),
    ).fetchall()

    return hourly, daily


def evaluate_and_notify(db: str = "db/weather.db") -> dict[str, int]:
    """
    Full evaluation + dispatch cycle for every location in the DB.

    Steps per location
    ------------------
    1. Query the next 48 h hourly rows + next 3 daily rows from SQLite.
    2. Run src.rules.evaluate() to get fired alerts.
    3. Call dispatch_if_new() — debounces and sends Telegram / email.

    Returns
    -------
    dict:
        locations_checked   – total locations evaluated
        total_alerts_fired  – sum of newly dispatched alerts
    """
    logger.info("── evaluate_and_notify started ─────────────────────────────")

    conn      = get_connection()
    locations = conn.execute(
        "SELECT id, name FROM locations ORDER BY id;"
    ).fetchall()

    if not locations:
        conn.close()
        logger.warning("No locations found — skipping evaluation.")
        return {"locations_checked": 0, "total_alerts_fired": 0}

    total_dispatched = 0

    for loc in locations:
        loc_id = loc["id"]
        name   = loc["name"]
        logger.info("  Evaluating [%d] %s …", loc_id, name)

        hourly_rows, daily_rows = _fetch_window(conn, loc_id)

        if not hourly_rows and not daily_rows:
            logger.info(
                "    ⚠ No forecast data for [%d] %s — run refresh first.", loc_id, name
            )
            continue

        fired      = evaluate(hourly_rows, daily_rows)
        dispatched = dispatch_if_new(loc_id, name, fired, conn)
        total_dispatched += len(dispatched)

    conn.close()

    logger.info(
        "── evaluate_and_notify done  locations=%d  dispatched=%d ──",
        len(locations), total_dispatched,
    )
    return {"locations_checked": len(locations), "total_alerts_fired": total_dispatched}


# ── Standalone entry point ─────────────────────────────────────────────────

if __name__ == "__main__":
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(name)s - %(message)s",
    )
    evaluate_and_notify()
