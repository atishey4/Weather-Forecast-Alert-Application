"""
api/app.py
==========
FastAPI application exposing weather data and alert endpoints.

Run with:
    uvicorn api.app:app --reload        (from project root)
    uvicorn api.app:app --host 0.0.0.0 --port 8000

Endpoints
---------
GET  /locations
POST /locations
GET  /forecast/hourly?location_id=&hours=24
GET  /forecast/daily?location_id=&days=7
GET  /alerts?location_id=
POST /refresh/{location_id}
"""

from __future__ import annotations

import logging
import sqlite3
import sys
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any, Generator

from fastapi import Depends, FastAPI, HTTPException, Query, status
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

# ── Path bootstrap (supports running as `uvicorn api.app:app` from root) ───
ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from db.init_db import get_connection          # noqa: E402
from src.ingest import fetch_open_meteo, persist_raw, upsert_series  # noqa: E402
from src.rules import evaluate                 # noqa: E402

logger = logging.getLogger(__name__)

# ── App setup ──────────────────────────────────────────────────────────────
app = FastAPI(
    title="Weather Forecast Alert API",
    description=(
        "Serves weather forecasts and rule-based alerts for monitored locations. "
        "Data is sourced from Open-Meteo and stored locally in SQLite."
    ),
    version="1.0.0",
    docs_url="/docs",
    redoc_url="/redoc",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)


# ── DB dependency ──────────────────────────────────────────────────────────

def get_db() -> Generator[sqlite3.Connection, None, None]:
    """FastAPI dependency — yields one SQLite connection per request."""
    conn = get_connection()
    try:
        yield conn
    finally:
        conn.close()


# ── Pydantic schemas ───────────────────────────────────────────────────────

class LocationIn(BaseModel):
    name: str  = Field(..., example="Chennai")
    lat:  float = Field(..., ge=-90,  le=90,  example=13.08)
    lon:  float = Field(..., ge=-180, le=180, example=80.27)
    tz:   str  = Field("Asia/Kolkata", example="Asia/Kolkata")


class LocationOut(BaseModel):
    id:   int
    name: str
    lat:  float
    lon:  float
    tz:   str


class HourlyRow(BaseModel):
    location_id:  int
    ts:           str
    temp_c:       float | None = None
    feels_c:      float | None = None
    humidity:     float | None = None
    wind_ms:      float | None = None
    wind_gust_ms: float | None = None
    precip_mm:    float | None = None
    precip_prob:  float | None = None
    cloud_pct:    float | None = None
    uv:           float | None = None
    pressure_hpa: float | None = None
    visibility_km:float | None = None
    weather_code: int   | None = None


class DailyRow(BaseModel):
    location_id:  int
    date:         str
    tmax_c:       float | None = None
    tmin_c:       float | None = None
    rain_mm:      float | None = None
    rain_prob:    float | None = None
    wind_max_ms:  float | None = None
    uv_max:       float | None = None
    sunrise:      str   | None = None
    sunset:       str   | None = None


class AlertOut(BaseModel):
    code:     str
    label:    str
    severity: str


class RefreshResult(BaseModel):
    location_id:    int
    hourly_fetched: int
    daily_fetched:  int
    raw_row_id:     int


# ── Helpers ────────────────────────────────────────────────────────────────

def _require_location(location_id: int, conn: sqlite3.Connection) -> dict[str, Any]:
    """Return the location row or raise 404."""
    row = conn.execute(
        "SELECT id, name, lat, lon, tz FROM locations WHERE id = ?", (location_id,)
    ).fetchone()
    if row is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Location {location_id} not found.",
        )
    return dict(row)


def _now_str() -> str:
    """Current local datetime as 'YYYY-MM-DDTHH:MM' for ts comparison."""
    return datetime.now().strftime("%Y-%m-%dT%H:%M")


def _future_str(hours: int = 0, days: int = 0) -> str:
    delta = timedelta(hours=hours, days=days)
    return (datetime.now() + delta).strftime("%Y-%m-%dT%H:%M")


# ── Endpoints ──────────────────────────────────────────────────────────────

# 1. GET /locations ─────────────────────────────────────────────────────────
@app.get(
    "/locations",
    response_model=list[LocationOut],
    summary="List all monitored locations",
    tags=["Locations"],
)
def list_locations(conn: sqlite3.Connection = Depends(get_db)) -> list[dict]:
    rows = conn.execute(
        "SELECT id, name, lat, lon, tz FROM locations ORDER BY id;"
    ).fetchall()
    return [dict(r) for r in rows]


# 2. POST /locations ────────────────────────────────────────────────────────
@app.post(
    "/locations",
    response_model=LocationOut,
    status_code=status.HTTP_201_CREATED,
    summary="Add a new monitored location",
    tags=["Locations"],
)
def add_location(
    body: LocationIn,
    conn: sqlite3.Connection = Depends(get_db),
) -> dict:
    try:
        cur = conn.execute(
            "INSERT INTO locations (name, lat, lon, tz) VALUES (?, ?, ?, ?);",
            (body.name, body.lat, body.lon, body.tz),
        )
        conn.commit()
    except sqlite3.IntegrityError:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=(
                f"A location at lat={body.lat}, lon={body.lon} already exists. "
                "Use PATCH to update it."
            ),
        )
    return {"id": cur.lastrowid, "name": body.name, "lat": body.lat, "lon": body.lon, "tz": body.tz}


# 3. GET /forecast/hourly ───────────────────────────────────────────────────
@app.get(
    "/forecast/hourly",
    response_model=list[HourlyRow],
    summary="Upcoming hourly forecast rows",
    tags=["Forecast"],
)
def get_hourly_forecast(
    location_id: int = Query(..., description="locations.id to query"),
    hours:       int = Query(24, ge=1, le=168, description="Window size in hours (max 168 = 7 days)"),
    conn: sqlite3.Connection = Depends(get_db),
) -> list[dict]:
    _require_location(location_id, conn)
    now_s   = _now_str()
    until_s = _future_str(hours=hours)
    rows = conn.execute(
        """
        SELECT * FROM weather_hourly
        WHERE location_id = ?
          AND ts >= ?
          AND ts <= ?
        ORDER BY ts;
        """,
        (location_id, now_s, until_s),
    ).fetchall()
    return [dict(r) for r in rows]


# 4. GET /forecast/daily ────────────────────────────────────────────────────
@app.get(
    "/forecast/daily",
    response_model=list[DailyRow],
    summary="Upcoming daily forecast rows",
    tags=["Forecast"],
)
def get_daily_forecast(
    location_id: int = Query(..., description="locations.id to query"),
    days:        int = Query(7, ge=1, le=16, description="Number of upcoming days (max 16)"),
    conn: sqlite3.Connection = Depends(get_db),
) -> list[dict]:
    _require_location(location_id, conn)
    today_s = datetime.now().date().isoformat()
    until_s = (datetime.now().date() + timedelta(days=days)).isoformat()
    rows = conn.execute(
        """
        SELECT * FROM weather_daily
        WHERE location_id = ?
          AND date >= ?
          AND date <= ?
        ORDER BY date;
        """,
        (location_id, today_s, until_s),
    ).fetchall()
    return [dict(r) for r in rows]


# 5. GET /alerts ────────────────────────────────────────────────────────────
@app.get(
    "/alerts",
    response_model=list[AlertOut],
    summary="Evaluate and return fired alert rules for a location",
    tags=["Alerts"],
)
def get_alerts(
    location_id: int = Query(..., description="locations.id to evaluate"),
    conn: sqlite3.Connection = Depends(get_db),
) -> list[dict]:
    _require_location(location_id, conn)

    now_s    = _now_str()
    h48_s    = _future_str(hours=48)
    today_s  = datetime.now().date().isoformat()
    day3_s   = (datetime.now().date() + timedelta(days=3)).isoformat()

    hourly_rows = conn.execute(
        """
        SELECT * FROM weather_hourly
        WHERE location_id = ?
          AND ts >= ?
          AND ts <= ?
        ORDER BY ts;
        """,
        (location_id, now_s, h48_s),
    ).fetchall()

    daily_rows = conn.execute(
        """
        SELECT * FROM weather_daily
        WHERE location_id = ?
          AND date >= ?
          AND date <= ?
        ORDER BY date;
        """,
        (location_id, today_s, day3_s),
    ).fetchall()

    fired = evaluate(hourly_rows, daily_rows)

    # Persist each fired alert to alert_log
    if fired:
        sent_at = datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ")
        conn.executemany(
            "INSERT INTO alert_log (location_id, code, sent_at) VALUES (?, ?, ?);",
            [(location_id, a["code"], sent_at) for a in fired],
        )
        conn.commit()

    return fired


# 6. POST /refresh/{location_id} ────────────────────────────────────────────
@app.post(
    "/refresh/{location_id}",
    response_model=RefreshResult,
    summary="Fetch fresh forecast data from Open-Meteo and persist it",
    tags=["Ingestion"],
)
def refresh_location(
    location_id: int,
    conn: sqlite3.Connection = Depends(get_db),
) -> dict:
    loc = _require_location(location_id, conn)

    try:
        payload = fetch_open_meteo(lat=loc["lat"], lon=loc["lon"], tz=loc["tz"])
    except Exception as exc:
        logger.error("Open-Meteo fetch failed for location %d: %s", location_id, exc)
        raise HTTPException(
            status_code=status.HTTP_502_BAD_GATEWAY,
            detail=f"Upstream fetch failed: {exc}",
        )

    raw_id = persist_raw(conn, location_id, payload, scope="full")
    upsert_series(conn, location_id, payload)

    hourly_count = len(payload.get("hourly", {}).get("time", []))
    daily_count  = len(payload.get("daily",  {}).get("time", []))

    return {
        "location_id":    location_id,
        "hourly_fetched": hourly_count,
        "daily_fetched":  daily_count,
        "raw_row_id":     raw_id,
    }


# ── Health check ───────────────────────────────────────────────────────────
@app.get("/health", tags=["Meta"], summary="API liveness probe")
def health() -> dict:
    return {"status": "ok", "version": app.version}
