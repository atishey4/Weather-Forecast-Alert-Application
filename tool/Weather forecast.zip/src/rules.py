"""
src/rules.py
============
Alert rule definitions and evaluation engine.

Public API
----------
AlertRule        – dataclass describing a single rule
DEFAULT_RULES    – list[AlertRule] with 5 built-in rules
evaluate(hourly_rows, daily_rows) → list[dict]
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from typing import Any, Callable, Literal

logger = logging.getLogger(__name__)

Severity = Literal["info", "warn", "critical"]


# ── Data class ─────────────────────────────────────────────────────────────

@dataclass(frozen=True)
class AlertRule:
    """
    Describes one alert rule.

    Attributes
    ----------
    code      : Unique machine identifier, e.g. "RAIN_SOON"
    label     : Human-readable description
    condition : callable(ctx: dict) → bool
                Receives a context dict built from hourly/daily rows;
                returns True when the alert should fire.
    severity  : "info" | "warn" | "critical"
    """

    code:      str
    label:     str
    condition: Callable[[dict[str, Any]], bool]
    severity:  Severity = "info"


# ── Context builder ────────────────────────────────────────────────────────

def _to_dict(row: Any) -> dict[str, Any]:
    """Convert a sqlite3.Row or plain dict to a dict."""
    if isinstance(row, dict):
        return row
    try:
        return dict(row)           # sqlite3.Row
    except TypeError:
        return {k: getattr(row, k) for k in vars(row)}


def _parse_ts(ts: str | None) -> datetime | None:
    """Parse an ISO-8601 timestamp string to an aware UTC datetime."""
    if not ts:
        return None
    try:
        # Open-Meteo returns local-time strings like "2024-06-01T12:00"
        dt = datetime.fromisoformat(ts)
        if dt.tzinfo is None:
            # Treat as UTC if no tz offset present
            dt = dt.replace(tzinfo=timezone.utc)
        return dt.astimezone(timezone.utc)
    except ValueError:
        return None


def _build_context(
    hourly_rows: list[Any],
    daily_rows:  list[Any],
) -> dict[str, Any]:
    """
    Build a context dict consumed by rule conditions.

    Keys
    ----
    hourly_next_6h   : hourly rows whose ts falls within the next 6 h
    hourly_next_12h  : hourly rows within the next 12 h
    hourly_next_24h  : hourly rows within the next 24 h
    today_daily      : daily row for today (UTC date), or None
    tomorrow_daily   : daily row for tomorrow (UTC date), or None
    """
    now       = datetime.now(timezone.utc)
    h6        = now + timedelta(hours=6)
    h12       = now + timedelta(hours=12)
    h24       = now + timedelta(hours=24)
    today_str     = now.date().isoformat()
    tomorrow_str  = (now.date() + timedelta(days=1)).isoformat()

    hourly_dicts: list[dict[str, Any]] = [_to_dict(r) for r in hourly_rows]
    daily_dicts:  list[dict[str, Any]] = [_to_dict(r) for r in daily_rows]

    def _in_window(row: dict, cutoff: datetime) -> bool:
        ts = _parse_ts(row.get("ts"))
        return ts is not None and now <= ts <= cutoff

    ctx: dict[str, Any] = {
        "hourly_next_6h":  [r for r in hourly_dicts if _in_window(r, h6)],
        "hourly_next_12h": [r for r in hourly_dicts if _in_window(r, h12)],
        "hourly_next_24h": [r for r in hourly_dicts if _in_window(r, h24)],
        "today_daily":     next((r for r in daily_dicts if r.get("date") == today_str),     None),
        "tomorrow_daily":  next((r for r in daily_dicts if r.get("date") == tomorrow_str),  None),
    }
    return ctx


# ── Helper predicates ──────────────────────────────────────────────────────

def _any_hourly(ctx: dict, window_key: str, field: str, op: Callable[[Any], bool]) -> bool:
    """Return True if *any* row in the given hourly window satisfies op(row[field])."""
    return any(
        op(row.get(field))
        for row in ctx[window_key]
        if row.get(field) is not None
    )


def _daily_field(ctx: dict, day_key: str, field: str, op: Callable[[Any], bool]) -> bool:
    """Return True if the daily row for day_key exists and satisfies op(row[field])."""
    row = ctx.get(day_key)
    if row is None:
        return False
    val = row.get(field)
    return val is not None and op(val)


# ── Default rules ──────────────────────────────────────────────────────────

DEFAULT_RULES: list[AlertRule] = [
    # 1. Rain likely within the next 12 hours
    AlertRule(
        code      = "RAIN_SOON",
        label     = "Rain expected in the next 12 hours (≥ 60 % probability)",
        severity  = "warn",
        condition = lambda ctx: _any_hourly(
            ctx, "hourly_next_12h", "precip_prob",
            lambda v: v >= 0.60,          # stored as fraction 0–1
        ),
    ),

    # 2. Heat wave — tomorrow's high ≥ 40 °C
    AlertRule(
        code      = "HEAT_WAVE",
        label     = "Heat wave alert: tomorrow's high ≥ 40 °C",
        severity  = "critical",
        condition = lambda ctx: _daily_field(
            ctx, "tomorrow_daily", "tmax_c",
            lambda v: v >= 40.0,
        ),
    ),

    # 3. High wind gusts within the next 24 hours
    AlertRule(
        code      = "WIND_HIGH",
        label     = "Strong wind gusts (≥ 15 m/s) expected in the next 24 hours",
        severity  = "warn",
        condition = lambda ctx: _any_hourly(
            ctx, "hourly_next_24h", "wind_gust_ms",
            lambda v: v >= 15.0,
        ),
    ),

    # 4. High UV today
    AlertRule(
        code      = "UV_HIGH",
        label     = "High UV index today (UV ≥ 8) — sun protection advised",
        severity  = "warn",
        condition = lambda ctx: _daily_field(
            ctx, "today_daily", "uv_max",
            lambda v: v >= 8.0,
        ),
    ),

    # 5. Fog risk — visibility < 1 km in next 6 hours
    AlertRule(
        code      = "FOG_RISK",
        label     = "Fog risk: visibility below 1 km expected in the next 6 hours",
        severity  = "info",
        condition = lambda ctx: _any_hourly(
            ctx, "hourly_next_6h", "visibility_km",
            lambda v: v < 1.0,
        ),
    ),
]


# ── Evaluate ───────────────────────────────────────────────────────────────

def evaluate(
    hourly_rows: list[Any],
    daily_rows:  list[Any],
    rules:       list[AlertRule] | None = None,
) -> list[dict[str, Any]]:
    """
    Evaluate alert rules against fetched weather data.

    Parameters
    ----------
    hourly_rows : rows from weather_hourly (sqlite3.Row, dict, or any object
                  with .ts, .precip_prob, .wind_gust_ms, .visibility_km attrs)
    daily_rows  : rows from weather_daily (similar shape)
    rules       : list of AlertRule to evaluate; defaults to DEFAULT_RULES

    Returns
    -------
    list of dicts, one per fired rule:
        {
            "code":     str,
            "label":    str,
            "severity": "info" | "warn" | "critical",
        }
    """
    if rules is None:
        rules = DEFAULT_RULES

    ctx    = _build_context(hourly_rows, daily_rows)
    fired: list[dict[str, Any]] = []

    for rule in rules:
        try:
            triggered = rule.condition(ctx)
        except Exception as exc:
            logger.warning("Rule %s raised an exception during evaluation: %s", rule.code, exc)
            triggered = False

        if triggered:
            alert = {"code": rule.code, "label": rule.label, "severity": rule.severity}
            fired.append(alert)
            logger.info("  ⚠  Alert fired: [%s] %s (%s)", rule.severity.upper(), rule.code, rule.label)

    if not fired:
        logger.info("  ✔ No alerts triggered.")

    return fired
