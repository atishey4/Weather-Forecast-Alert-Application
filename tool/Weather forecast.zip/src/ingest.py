"""
src/ingest.py
=============
Open-Meteo ingestion layer.

Public API
----------
fetch_open_meteo(lat, lon, tz)  → raw payload dict
persist_raw(conn, loc_id, payload, scope)
upsert_series(conn, loc_id, data)
"""

from __future__ import annotations

import json
import logging
import sqlite3
from datetime import datetime, timezone
from typing import Any

import httpx

logger = logging.getLogger(__name__)

# ── Open-Meteo endpoint ────────────────────────────────────────────────────
_BASE_URL = "https://api.open-meteo.com/v1/forecast"
_TIMEOUT  = 20.0   # seconds

_HOURLY_VARS: list[str] = [
    "temperature_2m",
    "relative_humidity_2m",
    "apparent_temperature",        # feels_like → feels_c
    "precipitation_probability",
    "precipitation",
    "wind_speed_10m",
    "wind_gusts_10m",
    "cloud_cover",
    "uv_index",
    "pressure_msl",
    "visibility",
    "weathercode",
]

_DAILY_VARS: list[str] = [
    "temperature_2m_max",
    "temperature_2m_min",
    "precipitation_sum",
    "precipitation_probability_max",
    "wind_speed_10m_max",
    "uv_index_max",
    "sunrise",
    "sunset",
]


# ── 1. Fetch ───────────────────────────────────────────────────────────────

def fetch_open_meteo(
    lat: float,
    lon: float,
    tz: str = "Asia/Kolkata",
) -> dict[str, Any]:
    """
    Call the Open-Meteo /v1/forecast endpoint and return the raw JSON dict.

    Parameters
    ----------
    lat, lon : geographic coordinates
    tz       : IANA timezone string (controls local-time fields like sunrise/sunset)

    Returns
    -------
    dict — full API response payload

    Raises
    ------
    httpx.HTTPStatusError  – on non-2xx response
    httpx.TimeoutException – on network timeout
    """
    params: dict[str, Any] = {
        "latitude":        lat,
        "longitude":       lon,
        "hourly":          ",".join(_HOURLY_VARS),
        "daily":           ",".join(_DAILY_VARS),
        "timezone":        tz,
        "wind_speed_unit": "ms",          # request m/s directly
        "forecast_days":   7,
    }

    logger.info("Fetching Open-Meteo forecast  lat=%.4f  lon=%.4f  tz=%s", lat, lon, tz)

    with httpx.Client(timeout=_TIMEOUT) as client:
        resp = client.get(_BASE_URL, params=params)
        resp.raise_for_status()

    payload: dict[str, Any] = resp.json()
    logger.info(
        "  ✔ Received %d hourly slots, %d daily slots",
        len(payload.get("hourly", {}).get("time", [])),
        len(payload.get("daily", {}).get("time", [])),
    )
    return payload


# ── 2. Persist raw ─────────────────────────────────────────────────────────

def persist_raw(
    conn: sqlite3.Connection,
    loc_id: int,
    payload: dict[str, Any],
    scope: str = "full",
    provider: str = "open-meteo",
) -> int:
    """
    Insert the raw API payload into weather_raw and return the new row id.

    Parameters
    ----------
    conn     : open SQLite connection
    loc_id   : locations.id FK
    payload  : raw dict from the API
    scope    : logical scope tag, e.g. "hourly" | "daily" | "full"
    provider : source label
    """
    fetched_at = datetime.now(timezone.utc).isoformat(timespec="seconds")
    sql = """
        INSERT INTO weather_raw (location_id, fetched_at, scope, provider, payload)
        VALUES (?, ?, ?, ?, ?);
    """
    cur = conn.execute(sql, (loc_id, fetched_at, scope, provider, json.dumps(payload)))
    conn.commit()
    logger.info("  ✔ Persisted raw payload  loc_id=%d  scope=%s  row_id=%d", loc_id, scope, cur.lastrowid)
    return cur.lastrowid  # type: ignore[return-value]


# ── 3. Upsert parsed series ────────────────────────────────────────────────

def _safe(value: Any) -> Any:
    """Return None when Open-Meteo sends null/None; pass through otherwise."""
    return None if value is None else value


def upsert_series(
    conn: sqlite3.Connection,
    loc_id: int,
    data: dict[str, Any],
) -> None:
    """
    Parse an Open-Meteo response dict and upsert rows into
    weather_hourly and weather_daily.

    Parameters
    ----------
    conn   : open SQLite connection
    loc_id : locations.id FK
    data   : full Open-Meteo payload (as returned by fetch_open_meteo)
    """
    _upsert_hourly(conn, loc_id, data.get("hourly", {}))
    _upsert_daily(conn, loc_id, data.get("daily", {}))
    conn.commit()


def _upsert_hourly(
    conn: sqlite3.Connection,
    loc_id: int,
    hourly: dict[str, list[Any]],
) -> None:
    """Parse and bulk-upsert weather_hourly rows."""
    times = hourly.get("time", [])
    if not times:
        logger.warning("No hourly data to upsert for loc_id=%d", loc_id)
        return

    sql = """
        INSERT OR REPLACE INTO weather_hourly
            (location_id, ts,
             temp_c, feels_c, humidity,
             wind_ms, wind_gust_ms,
             precip_mm, precip_prob,
             cloud_pct, uv, pressure_hpa,
             visibility_km, weather_code)
        VALUES
            (?, ?,
             ?, ?, ?,
             ?, ?,
             ?, ?,
             ?, ?, ?,
             ?, ?);
    """

    # Open-Meteo returns precipitation_probability as % (0–100); store as fraction
    precip_probs = hourly.get("precipitation_probability", [None] * len(times))
    # visibility in metres → km
    visibilities = hourly.get("visibility", [None] * len(times))

    rows = [
        (
            loc_id,
            ts,
            _safe(hourly.get("temperature_2m",      [None] * len(times))[i]),
            _safe(hourly.get("apparent_temperature", [None] * len(times))[i]),
            _safe(hourly.get("relative_humidity_2m", [None] * len(times))[i]),
            _safe(hourly.get("wind_speed_10m",       [None] * len(times))[i]),
            _safe(hourly.get("wind_gusts_10m",       [None] * len(times))[i]),
            _safe(hourly.get("precipitation",        [None] * len(times))[i]),
            # precip_prob: convert % → fraction
            (precip_probs[i] / 100.0) if precip_probs[i] is not None else None,
            _safe(hourly.get("cloud_cover",          [None] * len(times))[i]),
            _safe(hourly.get("uv_index",             [None] * len(times))[i]),
            _safe(hourly.get("pressure_msl",         [None] * len(times))[i]),
            # visibility: metres → km
            (visibilities[i] / 1000.0) if visibilities[i] is not None else None,
            _safe(hourly.get("weathercode",          [None] * len(times))[i]),
        )
        for i, ts in enumerate(times)
    ]

    conn.executemany(sql, rows)
    logger.info("  ✔ Upserted %d hourly rows for loc_id=%d", len(rows), loc_id)


def _upsert_daily(
    conn: sqlite3.Connection,
    loc_id: int,
    daily: dict[str, list[Any]],
) -> None:
    """Parse and bulk-upsert weather_daily rows."""
    dates = daily.get("time", [])
    if not dates:
        logger.warning("No daily data to upsert for loc_id=%d", loc_id)
        return

    sql = """
        INSERT OR REPLACE INTO weather_daily
            (location_id, date,
             tmax_c, tmin_c,
             rain_mm, rain_prob,
             wind_max_ms, uv_max,
             sunrise, sunset)
        VALUES
            (?, ?,
             ?, ?,
             ?, ?,
             ?, ?,
             ?, ?);
    """

    rain_probs = daily.get("precipitation_probability_max", [None] * len(dates))

    rows = [
        (
            loc_id,
            date,
            _safe(daily.get("temperature_2m_max",            [None] * len(dates))[i]),
            _safe(daily.get("temperature_2m_min",            [None] * len(dates))[i]),
            _safe(daily.get("precipitation_sum",             [None] * len(dates))[i]),
            # rain_prob: convert % → fraction
            (rain_probs[i] / 100.0) if rain_probs[i] is not None else None,
            _safe(daily.get("wind_speed_10m_max",            [None] * len(dates))[i]),
            _safe(daily.get("uv_index_max",                  [None] * len(dates))[i]),
            _safe(daily.get("sunrise",                       [None] * len(dates))[i]),
            _safe(daily.get("sunset",                        [None] * len(dates))[i]),
        )
        for i, date in enumerate(dates)
    ]

    conn.executemany(sql, rows)
    logger.info("  ✔ Upserted %d daily rows for loc_id=%d", len(rows), loc_id)
