"""
src/simulate.py
===============
Offline simulation pipeline — no API key required.

Loads data/sample_weather.json, upserts it for Delhi (location_id=1),
evaluates alerts, generates CSV report and all 4 matplotlib charts.

Usage:
    python src/simulate.py
    python -m src.simulate
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from db.init_db import get_connection, init       # noqa: E402
from src.ingest import upsert_series              # noqa: E402
from src.rules import evaluate                    # noqa: E402
from src.report import generate_report            # noqa: E402
from src.plots import (                           # noqa: E402
    temp_trend, rain_forecast, humidity_wind, alert_summary,
)

SAMPLE_JSON = ROOT / "data" / "sample_weather.json"
CITY        = "Delhi"
LOC_ID      = 1
SEV_ICON    = {"critical": "🔴", "warn": "⚠️ ", "info": "ℹ️ "}


# ── helpers ────────────────────────────────────────────────────────────────

def _hourly_df(conn, loc_id: int) -> pd.DataFrame:
    rows = conn.execute(
        "SELECT * FROM weather_hourly WHERE location_id=? ORDER BY ts;",
        (loc_id,),
    ).fetchall()
    return pd.DataFrame([dict(r) for r in rows]) if rows else pd.DataFrame()


def _daily_df(conn, loc_id: int) -> pd.DataFrame:
    rows = conn.execute(
        "SELECT * FROM weather_daily WHERE location_id=? ORDER BY date;",
        (loc_id,),
    ).fetchall()
    return pd.DataFrame([dict(r) for r in rows]) if rows else pd.DataFrame()


def _section(title: str) -> None:
    print(f"\n{'─'*55}")
    print(f"  {title}")
    print('─'*55)


# ── main simulation ────────────────────────────────────────────────────────

def run_simulation(db: str = "db/weather.db") -> None:
    print("\n" + "═"*55)
    print("  Weather Forecast Alert — Offline Simulation")
    print("  Using: data/sample_weather.json  →  Delhi")
    print("═"*55)

    # 1. Ensure DB + tables exist
    _section("Step 1 · Initialising database")
    init()

    # 2. Load sample payload
    _section("Step 2 · Loading sample_weather.json")
    with open(SAMPLE_JSON, encoding="utf-8") as f:
        payload = json.load(f)
    h_count = len(payload.get("hourly", {}).get("time", []))
    d_count = len(payload.get("daily",  {}).get("time", []))
    print(f"  Loaded  {h_count} hourly slots  ·  {d_count} daily slots")

    # 3. Upsert into SQLite
    _section("Step 3 · Upserting into SQLite")
    conn = get_connection()
    upsert_series(conn, LOC_ID, payload)

    # 4. Read back from DB for evaluation / charts
    h_df  = _hourly_df(conn, LOC_ID)
    d_df  = _daily_df(conn,  LOC_ID)
    conn.close()
    print(f"  DB now has {len(h_df)} hourly rows  ·  {len(d_df)} daily rows for {CITY}")

    # 5. Evaluate alerts (pass ALL rows — no time-window filter in simulation)
    _section("Step 4 · Evaluating alert rules")
    h_records = h_df.to_dict("records")
    d_records = d_df.to_dict("records")
    alerts = evaluate(h_records, d_records)

    if alerts:
        for a in alerts:
            icon = SEV_ICON.get(a["severity"], "•")
            print(f"  {icon} [{a['severity'].upper():8s}] {a['code']}")
            print(f"           {a['label']}")
    else:
        print("  ✅ No alerts triggered.")

    # 6. Generate CSV report
    _section("Step 5 · Generating CSV report")
    csv_path = generate_report(LOC_ID)
    print(f"  Saved → {csv_path}")

    # 7. Generate matplotlib charts
    _section("Step 6 · Generating matplotlib charts")

    if h_df.empty:
        print("  ⚠  No hourly data — skipping hourly charts.")
    else:
        p1 = temp_trend(h_df.head(24), CITY)
        print(f"  Chart 1 → {p1}")

        p3 = humidity_wind(h_df.head(24), CITY)
        print(f"  Chart 3 → {p3}")

    if d_df.empty:
        print("  ⚠  No daily data — skipping daily charts.")
    else:
        p2 = rain_forecast(d_df, CITY)
        print(f"  Chart 2 → {p2}")

    p4 = alert_summary(alerts, CITY)
    print(f"  Chart 4 → {p4}")

    # 8. Summary
    print("\n" + "═"*55)
    print(f"  Simulation complete!")
    print(f"  Alerts fired   : {len(alerts)}")
    print(f"  Charts saved   : outputs/")
    print(f"  Report saved   : reports/")
    print("═"*55 + "\n")


if __name__ == "__main__":
    import logging
    logging.basicConfig(
        level=logging.WARNING,            # suppress verbose DB logs for cleaner output
        format="%(asctime)s [%(levelname)s] %(message)s",
    )
    run_simulation()
