"""
src/app_streamlit.py
====================
Streamlit dashboard for Weather Forecast Alert Application.

Run with:
    streamlit run src/app_streamlit.py
"""
from __future__ import annotations

import sys
from datetime import datetime, timedelta
from pathlib import Path

import plotly.graph_objects as go
import streamlit as st
from dotenv import load_dotenv

# ── Path bootstrap ──────────────────────────────────────────────────────────
ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

load_dotenv(ROOT / ".env")

from db.init_db import get_connection                            # noqa: E402
from src.ingest import fetch_open_meteo, persist_raw, upsert_series  # noqa: E402
from src.rules import evaluate                                   # noqa: E402

# ── Page config (MUST be first Streamlit call) ──────────────────────────────
st.set_page_config(
    page_title="Weather Forecast · India",
    page_icon="🌤️",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ══════════════════════════════════════════════════════════════════════════════
# CSS
# ══════════════════════════════════════════════════════════════════════════════
st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap');

html, body, [class*="css"] { font-family: 'Inter', sans-serif; }

/* ── Background ── */
.stApp {
    background: linear-gradient(135deg, #0a0f1e 0%, #0d1b2a 50%, #0f2233 100%);
    min-height: 100vh;
}

/* ── Sidebar ── */
section[data-testid="stSidebar"] {
    background: linear-gradient(180deg, #0d1b2a 0%, #111827 100%);
    border-right: 1px solid rgba(99,179,237,0.15);
}
section[data-testid="stSidebar"] * { color: #cbd5e1 !important; }

/* ── KPI card ── */
.kpi-card {
    background: linear-gradient(135deg, rgba(255,255,255,0.06) 0%, rgba(255,255,255,0.02) 100%);
    border: 1px solid rgba(99,179,237,0.2);
    border-radius: 16px;
    padding: 20px 16px 16px;
    text-align: center;
    backdrop-filter: blur(10px);
    transition: transform .2s, box-shadow .2s;
}
.kpi-card:hover { transform: translateY(-3px); box-shadow: 0 8px 32px rgba(99,179,237,0.15); }
.kpi-icon  { font-size: 1.8rem; margin-bottom: 6px; }
.kpi-value { font-size: 2rem; font-weight: 700; color: #e2e8f0; line-height: 1.1; }
.kpi-label { font-size: 0.72rem; color: #64748b; letter-spacing: .08em; text-transform: uppercase; margin-top: 4px; }
.kpi-unit  { font-size: 1rem; color: #94a3b8; font-weight: 400; }

/* ── Alert pills ── */
.alert-row  { display: flex; flex-wrap: wrap; gap: 10px; margin: 12px 0 20px; }
.alert-pill {
    display: inline-flex; align-items: center; gap: 7px;
    padding: 7px 16px; border-radius: 999px;
    font-size: 0.82rem; font-weight: 600; letter-spacing: .02em;
    border: 1.5px solid; backdrop-filter: blur(6px);
}
.pill-critical { background: rgba(239,68,68,.15);  border-color: rgba(239,68,68,.5);  color: #fca5a5; }
.pill-warn     { background: rgba(245,158,11,.15); border-color: rgba(245,158,11,.5); color: #fcd34d; }
.pill-info     { background: rgba(59,130,246,.15); border-color: rgba(59,130,246,.5); color: #93c5fd; }
.no-alerts     { color: #4ade80; font-size: .9rem; }

/* ── Section header ── */
.section-header {
    font-size: .72rem; font-weight: 700; letter-spacing: .12em;
    text-transform: uppercase; color: #4a6fa5;
    border-bottom: 1px solid rgba(99,179,237,.12);
    padding-bottom: 6px; margin: 24px 0 12px;
}

/* ── Page title ── */
.dash-title {
    font-size: 2.1rem; font-weight: 800;
    background: linear-gradient(90deg, #63b3ed, #9f7aea);
    -webkit-background-clip: text; -webkit-text-fill-color: transparent;
    margin-bottom: 2px;
}
.dash-sub { color: #64748b; font-size: .9rem; margin-bottom: 8px; }

/* ── Refresh button ── */
div[data-testid="stButton"] > button {
    background: linear-gradient(135deg, #2563eb, #7c3aed);
    color: #fff; border: none; border-radius: 10px;
    font-weight: 600; padding: 10px 20px; width: 100%;
    transition: opacity .2s;
}
div[data-testid="stButton"] > button:hover { opacity: .85; }
</style>
""", unsafe_allow_html=True)

# ══════════════════════════════════════════════════════════════════════════════
# Chart theme
# ══════════════════════════════════════════════════════════════════════════════
_LAYOUT = dict(
    template="plotly_dark",
    paper_bgcolor="rgba(0,0,0,0)",
    plot_bgcolor="rgba(255,255,255,0.02)",
    margin=dict(l=10, r=10, t=36, b=10),
    font=dict(family="Inter, sans-serif", color="#94a3b8", size=12),
    xaxis=dict(gridcolor="rgba(255,255,255,0.05)", zeroline=False),
    yaxis=dict(gridcolor="rgba(255,255,255,0.05)", zeroline=False),
)


# ══════════════════════════════════════════════════════════════════════════════
# Data helpers
# ══════════════════════════════════════════════════════════════════════════════

@st.cache_data(ttl=60)
def load_locations() -> list[dict]:
    conn = get_connection()
    rows = conn.execute("SELECT id, name, lat, lon, tz FROM locations ORDER BY name;").fetchall()
    conn.close()
    return [dict(r) for r in rows]


@st.cache_data(ttl=120)
def load_hourly(loc_id: int, hours: int = 24) -> list[dict]:
    now   = datetime.now().strftime("%Y-%m-%dT%H:%M")
    until = (datetime.now() + timedelta(hours=hours)).strftime("%Y-%m-%dT%H:%M")
    conn  = get_connection()
    rows  = conn.execute(
        "SELECT * FROM weather_hourly WHERE location_id=? AND ts>=? AND ts<=? ORDER BY ts;",
        (loc_id, now, until),
    ).fetchall()
    conn.close()
    return [dict(r) for r in rows]


@st.cache_data(ttl=120)
def load_daily(loc_id: int, days: int = 7) -> list[dict]:
    today = datetime.now().date().isoformat()
    until = (datetime.now().date() + timedelta(days=days)).isoformat()
    conn  = get_connection()
    rows  = conn.execute(
        "SELECT * FROM weather_daily WHERE location_id=? AND date>=? AND date<=? ORDER BY date;",
        (loc_id, today, until),
    ).fetchall()
    conn.close()
    return [dict(r) for r in rows]


@st.cache_data(ttl=120)
def load_current(loc_id: int) -> dict | None:
    now  = datetime.now().strftime("%Y-%m-%dT%H:%M")
    conn = get_connection()
    row  = conn.execute(
        "SELECT * FROM weather_hourly WHERE location_id=? AND ts>=? ORDER BY ts LIMIT 1;",
        (loc_id, now),
    ).fetchone()
    conn.close()
    return dict(row) if row else None


def run_evaluate(loc_id: int) -> list[dict]:
    hourly = load_hourly.__wrapped__(loc_id, 48)  # bypass cache
    daily  = load_daily.__wrapped__(loc_id, 3)
    return evaluate(hourly, daily)


def do_refresh(loc: dict) -> str:
    """Fetch from Open-Meteo and persist for one location."""
    try:
        payload = fetch_open_meteo(loc["lat"], loc["lon"], loc["tz"])
        conn = get_connection()
        persist_raw(conn, loc["id"], payload, scope="full")
        upsert_series(conn, loc["id"], payload)
        conn.close()
        load_hourly.clear()
        load_daily.clear()
        load_current.clear()
        return "ok"
    except Exception as exc:
        return str(exc)


# ══════════════════════════════════════════════════════════════════════════════
# Sidebar
# ══════════════════════════════════════════════════════════════════════════════

with st.sidebar:
    st.markdown("### 🌍 Location")
    locations = load_locations()

    if not locations:
        st.error("No locations in DB. Run `python db/init_db.py` first.")
        st.stop()

    loc_names = [l["name"] for l in locations]
    selected_name = st.selectbox("Select city", loc_names, label_visibility="collapsed")
    loc = next(l for l in locations if l["name"] == selected_name)

    st.markdown("---")
    if st.button("🔄 Refresh Data", key="refresh_btn"):
        with st.spinner(f"Fetching latest data for {loc['name']}…"):
            result = do_refresh(loc)
        if result == "ok":
            st.success("Data refreshed!")
        else:
            st.error(f"Fetch failed: {result}")

    st.markdown("---")
    st.markdown(
        f"<div style='color:#475569;font-size:.75rem;'>"
        f"Lat {loc['lat']}° · Lon {loc['lon']}°<br>"
        f"Timezone: {loc['tz']}<br>"
        f"Data: Open-Meteo (free)</div>",
        unsafe_allow_html=True,
    )

# ══════════════════════════════════════════════════════════════════════════════
# Load data for selected location
# ══════════════════════════════════════════════════════════════════════════════

current   = load_current(loc["id"])
hourly_24 = load_hourly(loc["id"], hours=24)
daily_7   = load_daily(loc["id"],  days=7)

no_data = current is None and not hourly_24 and not daily_7

# ══════════════════════════════════════════════════════════════════════════════
# Header
# ══════════════════════════════════════════════════════════════════════════════

st.markdown(
    f"<div class='dash-title'>🌤️ {loc['name']}</div>"
    f"<div class='dash-sub'>Weather Forecast & Alert Dashboard · "
    f"{datetime.now().strftime('%d %b %Y, %H:%M')}</div>",
    unsafe_allow_html=True,
)

if no_data:
    st.warning("⚠️ No forecast data yet. Click **Refresh Data** in the sidebar to fetch from Open-Meteo.")
    st.stop()

# ══════════════════════════════════════════════════════════════════════════════
# KPI Row
# ══════════════════════════════════════════════════════════════════════════════

def _val(d: dict | None, key: str, fmt: str = ".1f", fallback: str = "—") -> str:
    if d is None:
        return fallback
    v = d.get(key)
    return f"{v:{fmt}}" if v is not None else fallback

st.markdown("<div class='section-header'>Current Conditions</div>", unsafe_allow_html=True)

kpi_cols = st.columns(5)
kpis = [
    ("🌡️", _val(current, "temp_c"),    "°C", "Temperature"),
    ("🤔", _val(current, "feels_c"),   "°C", "Feels Like"),
    ("💧", _val(current, "humidity",  fmt=".0f"), "%",    "Humidity"),
    ("💨", _val(current, "wind_ms"),   "m/s","Wind Speed"),
    ("☀️", _val(current, "uv",        fmt=".1f"), "",    "UV Index"),
]
for col, (icon, val, unit, label) in zip(kpi_cols, kpis):
    col.markdown(
        f"<div class='kpi-card'>"
        f"<div class='kpi-icon'>{icon}</div>"
        f"<div class='kpi-value'>{val}<span class='kpi-unit'>{unit}</span></div>"
        f"<div class='kpi-label'>{label}</div>"
        f"</div>",
        unsafe_allow_html=True,
    )

# ══════════════════════════════════════════════════════════════════════════════
# Alert Badges
# ══════════════════════════════════════════════════════════════════════════════

st.markdown("<div class='section-header'>Active Alerts</div>", unsafe_allow_html=True)

alerts = run_evaluate(loc["id"])
_icons = {"critical": "🔴", "warn": "⚠️", "info": "ℹ️"}

if alerts:
    pills_html = "<div class='alert-row'>"
    for a in alerts:
        css = f"pill-{a['severity']}"
        icon = _icons.get(a["severity"], "•")
        pills_html += (
            f"<span class='alert-pill {css}'>{icon} {a['code']} — {a['label']}</span>"
        )
    pills_html += "</div>"
    st.markdown(pills_html, unsafe_allow_html=True)
else:
    st.markdown("<div class='no-alerts'>✅ No active alerts for this location.</div>", unsafe_allow_html=True)

# ══════════════════════════════════════════════════════════════════════════════
# Charts
# ══════════════════════════════════════════════════════════════════════════════

st.markdown("<div class='section-header'>Hourly Forecast — Next 24 Hours</div>", unsafe_allow_html=True)

col1, col2 = st.columns(2)

# ── Chart 1: 24h Temperature ────────────────────────────────────────────────
with col1:
    if hourly_24:
        times   = [r["ts"] for r in hourly_24]
        temps   = [r.get("temp_c")   for r in hourly_24]
        feels   = [r.get("feels_c")  for r in hourly_24]

        fig = go.Figure()
        fig.add_trace(go.Scatter(
            x=times, y=temps, name="Temp (°C)",
            line=dict(color="#f97316", width=2.5),
            fill="tozeroy", fillcolor="rgba(249,115,22,0.08)",
        ))
        fig.add_trace(go.Scatter(
            x=times, y=feels, name="Feels Like (°C)",
            line=dict(color="#60a5fa", width=1.5, dash="dot"),
        ))
        fig.update_layout(**_LAYOUT, title="🌡️ Temperature", yaxis_title="°C")
        st.plotly_chart(fig, use_container_width=True)
    else:
        st.info("No hourly data available.")

# ── Chart 2: 24h Precipitation Probability ──────────────────────────────────
with col2:
    if hourly_24:
        probs = [
            (r.get("precip_prob") or 0) * 100 for r in hourly_24
        ]
        fig = go.Figure()
        fig.add_trace(go.Scatter(
            x=times, y=probs, name="Precip Probability (%)",
            line=dict(color="#06b6d4", width=2.5),
            fill="tozeroy", fillcolor="rgba(6,182,212,0.12)",
        ))
        fig.update_layout(**_LAYOUT, title="🌧️ Precipitation Probability", yaxis_title="%", yaxis_range=[0, 105])
        st.plotly_chart(fig, use_container_width=True)
    else:
        st.info("No hourly data available.")

st.markdown("<div class='section-header'>7-Day Forecast</div>", unsafe_allow_html=True)

col3, col4 = st.columns(2)

# ── Chart 3: 7-day Max/Min temperature range ────────────────────────────────
with col3:
    if daily_7:
        dates = [r["date"]   for r in daily_7]
        tmax  = [r.get("tmax_c") for r in daily_7]
        tmin  = [r.get("tmin_c") for r in daily_7]

        fig = go.Figure()
        # Fill band between min and max
        fig.add_trace(go.Scatter(
            x=dates + dates[::-1],
            y=tmax + tmin[::-1],
            fill="toself",
            fillcolor="rgba(139,92,246,0.15)",
            line=dict(color="rgba(0,0,0,0)"),
            name="Temp Range",
            hoverinfo="skip",
        ))
        fig.add_trace(go.Scatter(
            x=dates, y=tmax, name="Max (°C)",
            line=dict(color="#f97316", width=2.5),
            mode="lines+markers", marker=dict(size=6),
        ))
        fig.add_trace(go.Scatter(
            x=dates, y=tmin, name="Min (°C)",
            line=dict(color="#60a5fa", width=2.5),
            mode="lines+markers", marker=dict(size=6),
        ))
        fig.update_layout(**_LAYOUT, title="🌡️ Daily Max / Min Temperature", yaxis_title="°C")
        st.plotly_chart(fig, use_container_width=True)
    else:
        st.info("No daily data available.")

# ── Chart 4: 7-day Rain mm bar chart ────────────────────────────────────────
with col4:
    if daily_7:
        rain  = [r.get("rain_mm") or 0 for r in daily_7]
        probs = [(r.get("rain_prob") or 0) * 100 for r in daily_7]

        fig = go.Figure()
        fig.add_trace(go.Bar(
            x=dates, y=rain, name="Rain (mm)",
            marker=dict(
                color=rain,
                colorscale=[[0, "rgba(59,130,246,0.4)"], [1, "#06b6d4"]],
                showscale=False,
            ),
        ))
        fig.add_trace(go.Scatter(
            x=dates, y=probs, name="Rain Prob (%)",
            yaxis="y2",
            line=dict(color="#a78bfa", width=2, dash="dot"),
            mode="lines+markers", marker=dict(size=5),
        ))
        fig.update_layout(
            **_LAYOUT,
            title="🌧️ Daily Rainfall & Probability",
            yaxis_title="mm",
            yaxis2=dict(
                title="Probability (%)",
                overlaying="y",
                side="right",
                range=[0, 110],
                gridcolor="rgba(0,0,0,0)",
                color="#a78bfa",
            ),
            legend=dict(orientation="h", y=-0.15),
        )
        st.plotly_chart(fig, use_container_width=True)
    else:
        st.info("No daily data available.")

# ── Footer ──────────────────────────────────────────────────────────────────
st.markdown(
    "<div style='text-align:center;color:#1e293b;font-size:.75rem;margin-top:32px;'>"
    "Data provided by <a href='https://open-meteo.com' style='color:#334155;'>Open-Meteo</a> · "
    "Weather Forecast Alert Application</div>",
    unsafe_allow_html=True,
)
