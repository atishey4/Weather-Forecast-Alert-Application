"""
src/report.py
=============
Generates CSV forecast reports from SQLite data.

Public API
----------
generate_report(location_id, db="db/weather.db") → Path
"""

from __future__ import annotations

import sys
from datetime import datetime, timedelta
from pathlib import Path

import pandas as pd

# ── Path bootstrap ──────────────────────────────────────────────────────────
ROOT    = Path(__file__).resolve().parent.parent
REPORTS = ROOT / "reports"
REPORTS.mkdir(parents=True, exist_ok=True)

if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from db.init_db import get_connection  # noqa: E402


# ══════════════════════════════════════════════════════════════════════════════
# Helpers
# ══════════════════════════════════════════════════════════════════════════════

def _load_hourly(conn, location_id: int, hours: int = 168) -> pd.DataFrame:
    """Return next `hours` hours of weather_hourly rows as a DataFrame."""
    now   = datetime.now().strftime("%Y-%m-%dT%H:%M")
    until = (datetime.now() + timedelta(hours=hours)).strftime("%Y-%m-%dT%H:%M")
    rows  = conn.execute(
        """
        SELECT
            ts,
            temp_c, feels_c, humidity,
            wind_ms, wind_gust_ms,
            precip_mm, precip_prob,
            cloud_pct, uv, pressure_hpa,
            visibility_km, weather_code
        FROM weather_hourly
        WHERE location_id = ? AND ts >= ? AND ts <= ?
        ORDER BY ts;
        """,
        (location_id, now, until),
    ).fetchall()
    df = pd.DataFrame(rows, columns=[d[0] for d in conn.execute(
        "SELECT * FROM weather_hourly LIMIT 0;"
    ).description] if not rows else None)
    if rows:
        df = pd.DataFrame(
            [dict(r) for r in rows]
        )
    else:
        df = pd.DataFrame(columns=[
            "ts", "temp_c", "feels_c", "humidity",
            "wind_ms", "wind_gust_ms", "precip_mm", "precip_prob",
            "cloud_pct", "uv", "pressure_hpa", "visibility_km", "weather_code",
        ])
    df["record_type"] = "hourly"
    df["date"]        = pd.to_datetime(df["ts"]).dt.date.astype(str)
    return df


def _load_daily(conn, location_id: int, days: int = 7) -> pd.DataFrame:
    """Return next `days` days of weather_daily rows as a DataFrame."""
    today = datetime.now().date().isoformat()
    until = (datetime.now().date() + timedelta(days=days)).isoformat()
    rows  = conn.execute(
        """
        SELECT
            date,
            tmax_c, tmin_c,
            rain_mm, rain_prob,
            wind_max_ms, uv_max,
            sunrise, sunset
        FROM weather_daily
        WHERE location_id = ? AND date >= ? AND date <= ?
        ORDER BY date;
        """,
        (location_id, today, until),
    ).fetchall()
    if rows:
        df = pd.DataFrame([dict(r) for r in rows])
    else:
        df = pd.DataFrame(columns=[
            "date", "tmax_c", "tmin_c", "rain_mm", "rain_prob",
            "wind_max_ms", "uv_max", "sunrise", "sunset",
        ])
    df["record_type"] = "daily"
    return df


def _merge(hourly_df: pd.DataFrame, daily_df: pd.DataFrame) -> pd.DataFrame:
    """
    Left-join daily summary columns onto each hourly row by date,
    producing one enriched row per hour.
    """
    if hourly_df.empty:
        return hourly_df

    if not daily_df.empty:
        daily_slim = daily_df[[
            "date", "tmax_c", "tmin_c", "rain_mm", "rain_prob",
            "wind_max_ms", "uv_max", "sunrise", "sunset",
        ]].rename(columns={
            "tmax_c":    "day_tmax_c",
            "tmin_c":    "day_tmin_c",
            "rain_mm":   "day_rain_mm",
            "rain_prob": "day_rain_prob",
            "wind_max_ms": "day_wind_max_ms",
            "uv_max":    "day_uv_max",
            "sunrise":   "day_sunrise",
            "sunset":    "day_sunset",
        })
        merged = hourly_df.merge(daily_slim, on="date", how="left")
    else:
        merged = hourly_df.copy()

    # Reorder columns for readability
    front = ["date", "ts", "record_type"]
    rest  = [c for c in merged.columns if c not in front]
    merged = merged[front + rest]

    return merged


# ══════════════════════════════════════════════════════════════════════════════
# Public function
# ══════════════════════════════════════════════════════════════════════════════

def generate_report(
    location_id: int,
    db: str = "db/weather.db",
    hourly_hours: int = 168,
    daily_days:   int = 7,
) -> Path:
    """
    Query weather_hourly and weather_daily for the given location, merge them
    into a single enriched DataFrame, and write a CSV to reports/.

    Parameters
    ----------
    location_id  : locations.id to report on
    db           : path to SQLite DB (relative to project root or absolute)
    hourly_hours : how many upcoming hours of hourly data to include (default 168 = 7 days)
    daily_days   : how many upcoming days of daily data to include

    Returns
    -------
    Path to the written CSV file.

    Output columns
    --------------
    date, ts, record_type,
    temp_c, feels_c, humidity, wind_ms, wind_gust_ms,
    precip_mm, precip_prob, cloud_pct, uv, pressure_hpa,
    visibility_km, weather_code,
    day_tmax_c, day_tmin_c, day_rain_mm, day_rain_prob,
    day_wind_max_ms, day_uv_max, day_sunrise, day_sunset
    """
    conn = get_connection()

    # Resolve city name
    loc_row = conn.execute(
        "SELECT name FROM locations WHERE id = ?;", (location_id,)
    ).fetchone()
    if loc_row is None:
        conn.close()
        raise ValueError(f"Location {location_id} not found in DB.")
    city_name = loc_row["name"]

    hourly_df = _load_hourly(conn, location_id, hourly_hours)
    daily_df  = _load_daily(conn,  location_id, daily_days)
    conn.close()

    merged = _merge(hourly_df, daily_df)

    # Round float columns to 2 decimal places for clean CSVs
    float_cols = merged.select_dtypes(include="float").columns
    merged[float_cols] = merged[float_cols].round(2)

    # Precip probability → percent for human readability
    for col in ["precip_prob", "day_rain_prob"]:
        if col in merged.columns:
            merged[col] = (merged[col] * 100).round(1)
            merged.rename(columns={col: col.replace("_prob", "_prob_pct")}, inplace=True)

    slug = city_name.lower().replace(" ", "_")
    out_path = REPORTS / f"{slug}_forecast.csv"
    merged.to_csv(out_path, index=False, encoding="utf-8-sig")

    print(
        f"Report written → {out_path}  "
        f"({len(merged)} rows, {len(merged.columns)} columns)"
    )
    return out_path


# ── Standalone entry point ─────────────────────────────────────────────────

if __name__ == "__main__":
    import logging
    logging.basicConfig(level=logging.INFO,
                        format="%(asctime)s [%(levelname)s] %(message)s")

    conn = get_connection()
    locs = conn.execute("SELECT id, name FROM locations ORDER BY id;").fetchall()
    conn.close()

    if not locs:
        print("No locations in DB. Run db/init_db.py first.")
        sys.exit(1)

    for loc in locs:
        path = generate_report(loc["id"])
        print(f"  ✔ [{loc['id']}] {loc['name']} → {path}")
