"""
src/plots.py
============
Matplotlib chart functions that save publication-quality PNGs to outputs/.

Public API
----------
temp_trend(df, city)          → Path
rain_forecast(df, city)       → Path
humidity_wind(df, city)       → Path
alert_summary(alerts, city)   → Path
"""

from __future__ import annotations

import sys
from datetime import datetime
from pathlib import Path
from typing import Any

import matplotlib.dates as mdates
import matplotlib.pyplot as plt
import matplotlib.ticker as mticker
import pandas as pd

# ── Path bootstrap ──────────────────────────────────────────────────────────
ROOT       = Path(__file__).resolve().parent.parent
OUTPUTS    = ROOT / "outputs"
OUTPUTS.mkdir(parents=True, exist_ok=True)

if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

# ══════════════════════════════════════════════════════════════════════════════
# Global style
# ══════════════════════════════════════════════════════════════════════════════

_BG        = "#0d1117"
_FG        = "#e6edf3"
_GRID      = "#21262d"
_ACCENT1   = "#f97316"   # orange  — temperature
_ACCENT2   = "#60a5fa"   # blue    — feels-like / wind / humidity
_ACCENT3   = "#06b6d4"   # cyan    — rain
_ACCENT4   = "#a78bfa"   # purple  — secondary axis

_SEV_COLORS = {
    "critical": "#ef4444",
    "warn":     "#f59e0b",
    "info":     "#3b82f6",
}

plt.rcParams.update({
    "figure.facecolor":  _BG,
    "axes.facecolor":    _BG,
    "axes.edgecolor":    _GRID,
    "axes.labelcolor":   _FG,
    "axes.titlecolor":   _FG,
    "axes.titlesize":    13,
    "axes.labelsize":    10,
    "xtick.color":       "#8b949e",
    "ytick.color":       "#8b949e",
    "xtick.labelsize":   8,
    "ytick.labelsize":   8,
    "text.color":        _FG,
    "grid.color":        _GRID,
    "grid.linewidth":    0.6,
    "lines.linewidth":   2.0,
    "figure.dpi":        130,
    "savefig.dpi":       150,
    "savefig.bbox":      "tight",
    "savefig.facecolor": _BG,
    "font.family":       "DejaVu Sans",
    "legend.framealpha": 0.15,
    "legend.edgecolor":  _GRID,
    "legend.labelcolor": _FG,
    "legend.fontsize":   8,
})


def _slug(city: str) -> str:
    return city.lower().replace(" ", "_")


def _save(fig: plt.Figure, name: str) -> Path:
    path = OUTPUTS / name
    fig.savefig(path)
    plt.close(fig)
    return path


def _apply_grid(ax: plt.Axes) -> None:
    ax.grid(True, which="major", linestyle="--", alpha=0.4)
    ax.set_axisbelow(True)


# ══════════════════════════════════════════════════════════════════════════════
# 1. temp_trend — 24-hour temperature line chart
# ══════════════════════════════════════════════════════════════════════════════

def temp_trend(df: pd.DataFrame, city: str) -> Path:
    """
    24-hour temperature line chart with feels-like overlay and gradient fill.

    Parameters
    ----------
    df   : DataFrame with columns [ts, temp_c, feels_c]
           ts must be parseable by pd.to_datetime.
    city : location name (used in title and filename)

    Returns
    -------
    Path to the saved PNG.
    """
    df = df.copy()
    df["ts"] = pd.to_datetime(df["ts"])
    df = df.sort_values("ts").head(24)

    fig, ax = plt.subplots(figsize=(10, 4))
    fig.subplots_adjust(top=0.88)

    # Temperature fill
    ax.fill_between(df["ts"], df["temp_c"], alpha=0.15, color=_ACCENT1)
    ax.plot(df["ts"], df["temp_c"], color=_ACCENT1, label="Temperature (°C)", zorder=3)

    if "feels_c" in df.columns and df["feels_c"].notna().any():
        ax.plot(df["ts"], df["feels_c"], color=_ACCENT2, linestyle="--",
                linewidth=1.5, label="Feels Like (°C)", zorder=3)

    # Annotate min / max
    for col, clr in [("temp_c", _ACCENT1)]:
        if df[col].notna().any():
            idx_max = df[col].idxmax()
            idx_min = df[col].idxmin()
            for idx, sym in [(idx_max, "▲"), (idx_min, "▼")]:
                ax.annotate(
                    f"{sym}{df.loc[idx, col]:.1f}°",
                    xy=(df.loc[idx, "ts"], df.loc[idx, col]),
                    xytext=(0, 8 if sym == "▲" else -16),
                    textcoords="offset points",
                    fontsize=7.5, color=clr, ha="center",
                )

    ax.xaxis.set_major_formatter(mdates.DateFormatter("%H:%M"))
    ax.xaxis.set_major_locator(mdates.HourLocator(interval=3))
    fig.autofmt_xdate(rotation=0, ha="center")
    _apply_grid(ax)

    ax.set_title(f"🌡️  24-Hour Temperature — {city}", pad=10, fontweight="bold")
    ax.set_ylabel("Temperature (°C)")
    ax.legend(loc="upper right")

    return _save(fig, f"{_slug(city)}_temp_trend.png")


# ══════════════════════════════════════════════════════════════════════════════
# 2. rain_forecast — 7-day rainfall bar chart
# ══════════════════════════════════════════════════════════════════════════════

def rain_forecast(df: pd.DataFrame, city: str) -> Path:
    """
    7-day daily rainfall bar chart with precipitation probability overlay.

    Parameters
    ----------
    df   : DataFrame with columns [date, rain_mm, rain_prob]
           rain_prob expected as fraction 0–1.
    city : location name
    """
    df = df.copy()
    df["date"] = pd.to_datetime(df["date"])
    df = df.sort_values("date").head(7)

    fig, ax1 = plt.subplots(figsize=(10, 4))
    fig.subplots_adjust(top=0.88)
    ax2 = ax1.twinx()

    # Bars — rain_mm
    rain = df["rain_mm"].fillna(0)
    colors = [
        _ACCENT3 if v >= 5 else "#0e7490"
        for v in rain
    ]
    bars = ax1.bar(
        df["date"], rain, color=colors,
        width=0.6, zorder=3, alpha=0.85, label="Rain (mm)",
    )
    ax1.bar_label(bars, fmt="%.1f", padding=3, color="#94a3b8", fontsize=7.5)

    # Line — rain_prob %
    if "rain_prob" in df.columns and df["rain_prob"].notna().any():
        probs = df["rain_prob"].fillna(0) * 100
        ax2.plot(
            df["date"], probs,
            color=_ACCENT4, marker="o", markersize=5,
            linewidth=1.8, label="Rain Probability (%)", zorder=4,
        )
        ax2.set_ylabel("Probability (%)", color=_ACCENT4, fontsize=9)
        ax2.tick_params(axis="y", labelcolor=_ACCENT4)
        ax2.set_ylim(0, 115)
        ax2.yaxis.set_major_formatter(mticker.FormatStrFormatter("%d%%"))

    ax1.xaxis.set_major_formatter(mdates.DateFormatter("%d %b"))
    fig.autofmt_xdate(rotation=0, ha="center")
    _apply_grid(ax1)

    ax1.set_title(f"🌧️  7-Day Rainfall Forecast — {city}", pad=10, fontweight="bold")
    ax1.set_ylabel("Rainfall (mm)")
    ax1.set_ylim(bottom=0)

    lines1, labels1 = ax1.get_legend_handles_labels()
    lines2, labels2 = ax2.get_legend_handles_labels()
    ax1.legend(lines1 + lines2, labels1 + labels2, loc="upper right")

    return _save(fig, f"{_slug(city)}_rain_forecast.png")


# ══════════════════════════════════════════════════════════════════════════════
# 3. humidity_wind — dual-axis: humidity % + wind speed
# ══════════════════════════════════════════════════════════════════════════════

def humidity_wind(df: pd.DataFrame, city: str) -> Path:
    """
    Dual-axis chart: humidity % (filled area) and wind speed m/s (line).

    Parameters
    ----------
    df   : DataFrame with columns [ts, humidity, wind_ms, wind_gust_ms]
    city : location name
    """
    df = df.copy()
    df["ts"] = pd.to_datetime(df["ts"])
    df = df.sort_values("ts").head(24)

    fig, ax1 = plt.subplots(figsize=(10, 4))
    fig.subplots_adjust(top=0.88)
    ax2 = ax1.twinx()

    # Left axis — humidity
    hum = df["humidity"].fillna(method="ffill")
    ax1.fill_between(df["ts"], hum, alpha=0.18, color=_ACCENT2)
    ax1.plot(df["ts"], hum, color=_ACCENT2, label="Humidity (%)", zorder=3)
    ax1.set_ylabel("Humidity (%)", color=_ACCENT2)
    ax1.tick_params(axis="y", labelcolor=_ACCENT2)
    ax1.set_ylim(0, 110)

    # Right axis — wind speed + gusts
    if "wind_ms" in df.columns and df["wind_ms"].notna().any():
        ax2.plot(df["ts"], df["wind_ms"].fillna(0),
                 color=_ACCENT1, linewidth=2, label="Wind (m/s)", zorder=4)
    if "wind_gust_ms" in df.columns and df["wind_gust_ms"].notna().any():
        ax2.plot(df["ts"], df["wind_gust_ms"].fillna(0),
                 color=_ACCENT4, linewidth=1.5, linestyle=":",
                 label="Gusts (m/s)", zorder=4)
    ax2.set_ylabel("Wind Speed (m/s)", color=_ACCENT1)
    ax2.tick_params(axis="y", labelcolor=_ACCENT1)
    ax2.set_ylim(bottom=0)

    ax1.xaxis.set_major_formatter(mdates.DateFormatter("%H:%M"))
    ax1.xaxis.set_major_locator(mdates.HourLocator(interval=3))
    fig.autofmt_xdate(rotation=0, ha="center")
    _apply_grid(ax1)

    ax1.set_title(f"💧  Humidity & Wind — {city}", pad=10, fontweight="bold")

    lines1, labels1 = ax1.get_legend_handles_labels()
    lines2, labels2 = ax2.get_legend_handles_labels()
    ax1.legend(lines1 + lines2, labels1 + labels2, loc="upper right")

    return _save(fig, f"{_slug(city)}_humidity_wind.png")


# ══════════════════════════════════════════════════════════════════════════════
# 4. alert_summary — horizontal bar chart of severity counts
# ══════════════════════════════════════════════════════════════════════════════

def alert_summary(alerts: list[dict[str, Any]], city: str) -> Path:
    """
    Horizontal bar chart showing count of alerts per severity level.

    Parameters
    ----------
    alerts : list of dicts with at least {"code": str, "severity": str}
    city   : location name
    """
    counts: dict[str, int] = {"critical": 0, "warn": 0, "info": 0}
    for a in alerts:
        sev = a.get("severity", "info")
        counts[sev] = counts.get(sev, 0) + 1

    labels = list(counts.keys())
    values = [counts[k] for k in labels]
    colors = [_SEV_COLORS[k] for k in labels]

    fig, ax = plt.subplots(figsize=(7, 3))
    fig.subplots_adjust(top=0.88)

    bars = ax.barh(labels, values, color=colors, alpha=0.85, height=0.45, zorder=3)
    ax.bar_label(bars, fmt="%d", padding=5, color=_FG, fontsize=10, fontweight="bold")

    ax.set_xlim(0, max(values or [1]) + 1.5)
    ax.xaxis.set_major_locator(mticker.MaxNLocator(integer=True))
    ax.invert_yaxis()
    _apply_grid(ax)

    ax.set_title(f"⚠️  Alert Summary — {city}", pad=10, fontweight="bold")
    ax.set_xlabel("Number of Alerts")

    if not any(values):
        ax.text(
            0.5, 0.5, "No active alerts ✅",
            transform=ax.transAxes, ha="center", va="center",
            fontsize=12, color="#4ade80",
        )

    return _save(fig, f"{_slug(city)}_alert_summary.png")
